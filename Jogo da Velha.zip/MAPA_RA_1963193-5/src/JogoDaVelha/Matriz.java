/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package JogoDaVelha;

/**
 *
 * @author ronil
 */

public class Matriz {
	
	String jogador = "X";
	String[][] matriz = {{"","",""},{"","",""},{"","",""}};
	

	public void jogadorVigente() {
            
        /*    
        if(setJogador((this.jogador.equals("X"))){
        System.ou.println("O");
        }else{
    System.ou.println("X");    
    }*/
        
        

            //operadores Ternarios
		setJogador((this.jogador.equals("X")) ? "O" : "X");
	}
       
	
	public boolean verificaVitoria() {
		return ((this.jogador.equals(this.matriz[0][0]) && 
                            this.jogador.equals(this.matriz[0][1]) && 
                                this.jogador.equals(this.matriz[0][2])) ||(this.jogador.equals(this.matriz[1][0]) && 
                                    this.jogador.equals(this.matriz[1][1]) && this.jogador.equals(this.matriz[1][2])) || (this.jogador.equals(this.matriz[2][0]) && 
                                        this.jogador.equals(this.matriz[2][1]) && this.jogador.equals(this.matriz[2][2])) || (this.jogador.equals(this.matriz[0][0]) && 
                                            this.jogador.equals(this.matriz[1][1]) && this.jogador.equals(this.matriz[2][2])) || (this.jogador.equals(this.matriz[0][2]) && 
                                                this.jogador.equals(this.matriz[1][1]) && this.jogador.equals(this.matriz[2][0])) || (this.jogador.equals(this.matriz[0][0]) && 
                                                    this.jogador.equals(this.matriz[1][0]) && this.jogador.equals(this.matriz[2][0])) || (this.jogador.equals(this.matriz[0][1]) && 
                                                        this.jogador.equals(this.matriz[1][1]) && this.jogador.equals(this.matriz[2][1])) || (this.jogador.equals(this.matriz[0][2]) && 
                                                            this.jogador.equals(this.matriz[1][2]) && this.jogador.equals(this.matriz[2][2])));
	}
	
	public boolean verificaQuadro() {
		int cont = 0;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				cont = (!this.matriz[i][j].equals("")) ? cont + 1 : cont;
			}
		}
		return (cont == 9);
	}

	public String getJogador() {
		return jogador;
	}

	public void setJogador(String jogador) {
		this.jogador = jogador;
	}
}
